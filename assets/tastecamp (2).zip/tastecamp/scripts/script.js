const receitas = [
    {
        titulo:'Bolo de Chocolate array',
        ingredientes:'Ingredientes bolo', 
        preparo:'Preparo do bolo'
    },
    {
        titulo:'Pudim de leite condensado array',
        ingredientes:'Ingredientes pudim', 
        preparo:'Preparo do pudim'
    },
    {
        titulo:'Doce de leite array', 
        ingredientes:'Ingredientes doce', 
        preparo:'Preparo do doce'
    }
];

axios.defaults.headers.common['Authorization'] = '8by0RNLlOTsRTYl7Fv9cTbvp';

function renderizarReceitas(){

    // pegar a lista ul no html
    const ulReceitas = document.querySelector('.receitas');
    ulReceitas.innerHTML = '';

    // percorrer a minha lista de receitas
    for( let i = 0; i < receitas.length; i++){
        // pergar receita por receita
        let receita = receitas[i];
        
        // criar um elemento <li>] e adicionar no meu elemento <ul>
        ulReceitas.innerHTML += `
            <li>
                <ion-icon name="fast-food-outline"></ion-icon>
                ${receita.titulo}
            </li>
        `;
    }
}

renderizarReceitas();

function adicionarReceita(){

    // pegar os dados que foram digitados pelo usuario nos inputs e textareas
    const campoTitulo = document.querySelector('.nome-receita');
    const campoIngredientes = document.querySelector('.ingredientes-receita');
    const campoPreparo = document.querySelector('.modo-preparo-receita');

    // criar um novo objeto com os dados da receita
    const novaReceita = {
        titulo: campoTitulo.value,
        ingredientes: campoIngredientes.value,
        preparo: campoPreparo.value
    };

    // adicionar uma nova receita no array de receitas
    // receitas.push( novaReceita );

    // enviar a nova receita para ser salva no servidor
    // 1 - preciso de uma ferramenta para fazer tudo funcionar => axios!!!!

    // 2 - enviar a nova receita para o servidor e pegar a resposta
    
    console.log('vai enviar a receita');

    const promessa = axios.post('https://mock-api.driven.com.br/api/v2/tastecamp/receitas', novaReceita);    
    // sucesso!
    promessa.then( receberResposta ); // agendando a execucao da funcao quando a resposta chegar no meu computador  
    promessa.catch( deuErro ); // executa uma função se ocorrer algum erro, falha, etc! 
    console.log('receita foi enviada ao servidor');

    

    renderizarReceitas();

}

function receberResposta(resposta){
    // 3 - processar a resposta    
    console.log(`A receita foi salva com sucesso com o id ${resposta.data.id}!!!!! :D`);
    console.log(resposta);
}

function deuErro(erro){
    console.log(`ocorreu algum problema ao tentar salvar a receita, tente mais tarde!`);
    console.log(erro);
}